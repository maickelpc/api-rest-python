from django.apps import AppConfig


class BlocoConfig(AppConfig):
    name = 'bloco'
