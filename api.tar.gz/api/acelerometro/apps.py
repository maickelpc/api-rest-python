from django.apps import AppConfig


class AcelerometroConfig(AppConfig):
    name = 'acelerometro'
