from django.contrib import admin
from .models import *
# Register your models here.
# admin.site.register(Bloco)
# admin.site.register(Graficator)
# admin.site.register(Acelerometro)
# admin.site.register(Aceleracao)
admin.site.register(ArquivoFdd)
admin.site.register(FDD)