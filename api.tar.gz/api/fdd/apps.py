from django.apps import AppConfig


class FddConfig(AppConfig):
    name = 'fdd'
